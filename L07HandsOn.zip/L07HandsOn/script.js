function regexChecker () {
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var regexFirst = /^[A-Z]/;
    var regexLast = /^[A-Z]/;
    var onlyLetters = /^[a-zA-Z]+$/
    if (firstName.match(regexFirst) && lastName.match(regexLast) && firstName.match(onlyLetters) && lastName.match(onlyLetters))
    {
        alert("Yay! Your inputs were all correct!");
    }
    else {
        alert("Oh no! Thats an invalid format!");
    }
}