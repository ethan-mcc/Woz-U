let newRequest = new XMLHttpRequest();
newRequest.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
        let albertEinstein = JSON.parse(this.responseText);
        document.getElementById("name").innerHTML = albertEinstein.name;
        document.getElementById("birthday").innerHTML = albertEinstein.birthday;
    }
}

function loadBio() {
    const xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let albertEinstein = JSON.parse(this.responseText);
            document.getElementById("bio").innerHTML = albertEinstein.bio;
        }
    };
    xhttp.open("GET", "einstein.json", true);
    xhttp.send();
}
newRequest.open("GET", "einstein.json", true);
newRequest.send();