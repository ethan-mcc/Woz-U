class Employee {
    constructor(name, salary, hireDate) {
      this.name = name;
      this.salary = salary;
      this.hireDate = hireDate;
    }
    getName() {
      console.log(this.name.toUpperCase());
    }
    getSalary() {
      console.log(this.salary);
    }
    getHireDate() {
      console.log(this.hireDate);
    }
  }
class Manager extends Employee {
    constructor (descriptionOfJob, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.descriptionOfJob = descriptionOfJob;
    }
    jobDescription() {
        console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " because " + this.descriptionOfJob);
    }
}
class Designer extends Employee {
    constructor (experience, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.experience = experience;
    }
    yearsExperience() {
        console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " has " + this.experience + " years of experience.");
    }
}
class SalesAssociate extends Employee {
    constructor (degrees, name, salary, hireDate) {
        super(name, salary, hireDate);
        this.degrees = degrees;
    }
    degreeCompleted() {
        console.log(this.name + " was hired on " + this.hireDate + " and makes " + this.salary + " with a " + this.degrees + " degree");
    }
}

let Jared = new Manager ("his dad owns the company.", "Jared", 120000, "5/12/19");
let Brock = new Designer ("designs for Apple", "Brock", 175000, "1/16/18");
let Emily = new SalesAssociate ("MBA", "Emily", 50000, "6/5/17");
Jared.jobDescription();
Brock.yearsExperience();
Emily.degreeCompleted();